//
//  version.h
//  Burstly
//
//  Created by Evgeny Dedovec on 11/16/11.
//  Copyright 2011 Burstly. All rights reserved.
//

#define LIB_VERSION						@"1.34.0.23370"
